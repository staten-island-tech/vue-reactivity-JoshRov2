<template>
  <div class="builder">
    <img src="https://images.squarespace-cdn.com/content/v1/55b67512e4b07d7972605c53/1441302436209-SMO2FB98PH2QDVYMKAVQ/75R.png" alt="tank">
  </div>
</template>

<style>
@media (min-width: 1024px) {
  .builder {
    min-height: 100vh;
    display: flex;
    align-items: center;
  }
  img {
    background-color: white;
    width: 1000px;
    border: 5px solid darkblue;
    border-radius: 15px;
  }
}
</style>
