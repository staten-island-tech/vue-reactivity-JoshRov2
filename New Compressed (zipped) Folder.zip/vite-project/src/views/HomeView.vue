<script setup>
import StoreCard from '../components/StoreCard.vue'
</script>

<template>
  <div>
    <StoreCard/>
  </div>
</template>
